<?php
/**
 * Plugin Name:       RH - Post Card
 * Plugin URI:        https://rubelhossain99.com/plugins/
 * Description:       This is a simple Post Card Plugin Power by Rubel Hossain. Short-code Name: [get_post_card]
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Rubel Hossain
 * Author URI:        https://rubelhossain99.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://github.com/rubelhossain999/
 * Text Domain:       postCard
 * Domain Path:       /languages
 */

 // Register Custom Post Type RH-Postcard
function create_rhpostcard_cpt() {

	$labels = array(
		'name' => _x( 'RH-Postcards', 'Post Type General Name', 'postCard' ),
		'singular_name' => _x( 'RH-Postcard', 'Post Type Singular Name', 'postCard' ),
		'menu_name' => _x( 'RH-Postcards', 'Admin Menu text', 'postCard' ),
		'name_admin_bar' => _x( 'RH-Postcard', 'Add New on Toolbar', 'postCard' ),
		'archives' => __( 'RH-Postcard Archives', 'postCard' ),
		'attributes' => __( 'RH-Postcard Attributes', 'postCard' ),
		'parent_item_colon' => __( 'Parent RH-Postcard:', 'postCard' ),
		'all_items' => __( 'All RH-Postcards', 'postCard' ),
		'add_new_item' => __( 'Add New RH-Postcard', 'postCard' ),
		'add_new' => __( 'Add New', 'postCard' ),
		'new_item' => __( 'New RH-Postcard', 'postCard' ),
		'edit_item' => __( 'Edit RH-Postcard', 'postCard' ),
		'update_item' => __( 'Update RH-Postcard', 'postCard' ),
		'view_item' => __( 'View RH-Postcard', 'postCard' ),
		'view_items' => __( 'View RH-Postcards', 'postCard' ),
		'search_items' => __( 'Search RH-Postcard', 'postCard' ),
		'not_found' => __( 'Not found', 'postCard' ),
		'not_found_in_trash' => __( 'Not found in Trash', 'postCard' ),
		'featured_image' => __( 'Featured Image', 'postCard' ),
		'set_featured_image' => __( 'Set featured image', 'postCard' ),
		'remove_featured_image' => __( 'Remove featured image', 'postCard' ),
		'use_featured_image' => __( 'Use as featured image', 'postCard' ),
		'insert_into_item' => __( 'Insert into RH-Postcard', 'postCard' ),
		'uploaded_to_this_item' => __( 'Uploaded to this RH-Postcard', 'postCard' ),
		'items_list' => __( 'RH-Postcards list', 'postCard' ),
		'items_list_navigation' => __( 'RH-Postcards list navigation', 'postCard' ),
		'filter_items_list' => __( 'Filter RH-Postcards list', 'postCard' ),
	);
	$args = array(
		'label' => __( 'RH-Postcard', 'postCard' ),
		'description' => __( '', 'postCard' ),
		'labels' => $labels,
		'menu_icon' => 'dashicons-admin-multisite',
		'supports' => array('title', 'editor', 'thumbnail', 'revisions', 'author', 'comments'),
		'taxonomies' => array(),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 20,
		'show_in_admin_bar' => true,
		'show_in_nav_menus' => true,
		'can_export' => true,
		'has_archive' => false,
		'hierarchical' => false,
		'exclude_from_search' => false,
		'show_in_rest' => false,
		'publicly_queryable' => true,
		'capability_type' => 'post',
	);
	register_post_type( 'rhpostcard', $args );

}
add_action( 'init', 'create_rhpostcard_cpt', 0 );

// Create Shortcode get_post_card
// Shortcode: [get_post_card post_count="3"]
function create_getpostcard_shortcode($atts) {

	$atts = shortcode_atts(
		array(
			'post_count' => '3',
		),
		$atts,
		'get_post_card'
	);

	$post_count = $atts['post_count'];

  // Custom WP query query
    $args_query = array(
      'post_type' => array('rhpostcard'),
      'post_status' => array('Published'),
      'posts_per_page' => 3,
      'order' => 'DESC',
    );

    $query = new WP_Query( $args_query );

    if ( $query->have_posts() ) {
      while ( $query->have_posts() ) {
        $query->the_post();

        ?>
          <section>
            <div class="container">
              <div class="row">
                <div class="col-md-12">
                  <div class="card"">
                    <img src="<?php echo get_the_post_thumbnail_url();?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo get_the_title();?></h5>
                      <p class="card-text"><?php echo get_the_content();?></p>
                      <a href="#" class="<?php the_permalink();?>">Go somewhere</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        <?php

      }
    } else {

    }

    wp_reset_postdata();
    

}
add_shortcode( 'get_post_card', 'create_getpostcard_shortcode' );

function wp_plugin_js_CSS(){

  wp_enqueue_style('Bootstrap_plugin', plugin_dir_url(__FILE__).'assets/css/bootstrap.min.css');
  wp_enqueue_style('Stylesheet', plugin_dir_url(__FILE__).'style.css');

}
add_action('wp_enqueue_scripts','wp_plugin_js_CSS');


